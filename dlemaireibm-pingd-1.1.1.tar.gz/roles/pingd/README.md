# pingDL is a forked repository containing a role that pings dependending on the os and for linux uses pingDL instead of ping module
# pingDL module is forked based on ansible standard ping module 
